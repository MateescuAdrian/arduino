#include <Arduino.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <WebSerial.h>
#include <WiFi.h>

// Servo pins - Adjust as necessary
const int SERVO_LEFT_PIN = 16;
const int SERVO_RIGHT_PIN = 17;
const int SERVO_SWEEP_PIN = 15;

const char *ssid = "ReZO6";
const char *password = "helloworld!!!";

AsyncWebServer server(80);

int currentLeftSpeed = 90;
int currentRightSpeed = 90;

unsigned long lastCommandTime = 0;
const unsigned long SERVO_TIMEOUT_MS = 200;

unsigned long lastSweepTime = 0;
const unsigned long SWEEP_INTERVAL = 20; // in milliseconds, adjust for speed
int sweepAngle = 0;
int sweepDirection = 1;

void setServoSpeed(int pin, int speed) {
  // speed 0-180 (90 is stop)
  int duty = map(speed, 0, 180, 26, 123); // ~1.5ms pulse at 90
  ledcWrite(pin, duty);
}

void setup() {
  Serial.begin(115200);
  delay(3000);

  // Configure Servo PWM, 50Hz, 10-bit resolution
  ledcAttach(SERVO_LEFT_PIN, 50, 10);
  ledcAttach(SERVO_RIGHT_PIN, 50, 10);
  ledcAttach(SERVO_SWEEP_PIN, 50, 10);

  // Stop servos initially
  setServoSpeed(SERVO_LEFT_PIN, 90);
  setServoSpeed(SERVO_RIGHT_PIN, 90);
  setServoSpeed(SERVO_SWEEP_PIN, sweepAngle);



  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  WiFi.setSleep(false);

  // Allow cross-origin requests
  DefaultHeaders::Instance().addHeader("Access-Control-Allow-Origin", "*");

  WebSerial.begin(&server);
  Serial.println(WiFi.localIP());

  // Drive endpoint with 2 params: m1 and m2
  server.on("/drive", HTTP_GET, [](AsyncWebServerRequest *request) {
    String response = "Commands Processed: ";
    bool updated = false;

    if (request->hasParam("m1")) {
      currentLeftSpeed = constrain(request->getParam("m1")->value().toInt(), 0, 180);
      setServoSpeed(SERVO_LEFT_PIN, currentLeftSpeed);
      response += "m1=" + String(currentLeftSpeed) + " ";
      updated = true;
    }

    if (request->hasParam("m2")) {
      currentRightSpeed = constrain(request->getParam("m2")->value().toInt(), 0, 180);
      setServoSpeed(SERVO_RIGHT_PIN, currentRightSpeed);
      response += "m2=" + String(currentRightSpeed) + " ";
      updated = true;
    }

    if (updated) {
      lastCommandTime = millis();
    }

    WebSerial.println(response);
    request->send(200, "text/plain", response);
  });

  server.begin();
  Serial.println("\nSUCCESS: Server Live!");
}

void loop() {
  unsigned long now = millis();

  // Auto-stop servos if no command received recently
  if (now - lastCommandTime > SERVO_TIMEOUT_MS) {
    if (currentLeftSpeed != 90) {
      currentLeftSpeed = 90;
      setServoSpeed(SERVO_LEFT_PIN, 90);
    }
    if (currentRightSpeed != 90) {
      currentRightSpeed = 90;
      setServoSpeed(SERVO_RIGHT_PIN, 90);
    }
  }

  // Sweep servo logic
  if (now - lastSweepTime > SWEEP_INTERVAL) {
    lastSweepTime = now;
    sweepAngle += sweepDirection;
    
    if (sweepAngle >= 90) {
      sweepAngle = 90;
      sweepDirection = -1;
    } else if (sweepAngle <= 0) {
      sweepAngle = 0;
      sweepDirection = 1;
    }
    
    setServoSpeed(SERVO_SWEEP_PIN, sweepAngle);
  }

  yield();
}